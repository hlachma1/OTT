@echo off
cd /d "%~dp0"
start "" "OTT.exe" -c
