#!/usr/bin/env python3
"""
Generate OTT's own 16x16 tile sheet -- the WW1 tileset (v8 group D, item D1).

The sheet is drawn PROGRAMMATICALLY so it can be regenerated at any time and
so a new terrain feature or race is one small edit away from having a tile.
Standard library only: no Pillow, no numpy.  It writes both files the game's
loaders need:

    lib/xtra/graf/16x16_ott.bmp   8-bit palettised, BI_RGB, bottom-up, a full
                                  256-entry colour table (bfOffBits = 1078).
                                  This is what src/readdib.c (Windows) and
                                  src/maid-x11.c ReadBMP() (X11) accept; the
                                  X11 reader does NOT skip BMP row padding, so
                                  the width must be a multiple of 4 -- 512 is.
    lib/xtra/graf/16x16_ott.png   8-bit RGBA, for the Cocoa frontend, which
                                  reads real alpha.  The BMP's magic
                                  transparency colour becomes alpha = 0; the
                                  terrain rows never use that colour, so they
                                  come out fully opaque.

Sheet geometry: 32 columns x 6 rows of 16x16 tiles = 512 x 96 pixels.  Both
Term_pict hooks mask the row out of the attr with & 0x3F and the column out of
the char with & 0x3F (0x40 is the alert/glow mask), so a tile's attr/char pair
is 0x80 + row / 0x80 + col, with 64 usable rows and columns.

Tile (0,0) is RESERVED and left entirely in the magic transparency colour:
every loader reads the transparency key from visual pixel (0,0).  Nothing is
ever mapped to it.

The mapping from features / races / OTT overlays to these tiles lives in
lib/pref/graf-ott.prf.  Run this script with --table to print the index table
that documents that mapping (NOTES-engine.md carries a copy).

Usage:
    python3 lib/xtra/graf/make-ott-tiles.py [--out-dir DIR] [--table] [--check]
"""

import argparse
import os
import struct
import sys
import zlib

TILE = 16
COLS = 32
ROWS = 6
WID = COLS * TILE
HGT = ROWS * TILE

# --------------------------------------------------------------------------
# The palette: a restrained WW1 set -- mud, chalk, khaki, field grey, water,
# rust -- plus the two side colours the ASCII display already uses (light blue
# for ours, red for theirs) so the tiles speak the same colour language.
# --------------------------------------------------------------------------
PAL = {
    "KEY": (255, 0, 255),  # magic transparency, tile (0,0) and sprite grounds
    "black": (16, 14, 12),
    "shadow": (32, 28, 24),
    "mud_dk": (56, 44, 32),
    "mud": (86, 68, 48),
    "mud_lt": (114, 94, 68),
    "mud_pale": (140, 118, 88),
    "chalk_dk": (140, 132, 108),
    "chalk": (176, 166, 140),
    "chalk_lt": (206, 198, 174),
    "sand_dk": (104, 90, 62),
    "sand": (144, 128, 92),
    "sand_lt": (176, 160, 120),
    "khaki_dk": (78, 76, 52),
    "khaki": (118, 116, 82),
    "khaki_lt": (150, 148, 112),
    "grey_dk": (58, 66, 64),
    "grey": (92, 100, 96),
    "grey_lt": (126, 134, 130),
    "water_dk": (40, 56, 68),
    "water": (58, 82, 98),
    "water_lt": (96, 124, 142),
    "rust_dk": (84, 46, 26),
    "rust": (128, 74, 40),
    "rust_lt": (168, 106, 58),
    "blood_dk": (88, 18, 16),
    "blood": (146, 32, 28),
    "red": (198, 54, 44),
    "steel_dk": (74, 78, 82),
    "steel": (118, 124, 130),
    "steel_lt": (166, 172, 178),
    "silver": (204, 208, 212),
    "white": (234, 234, 228),
    "smoke_dk": (122, 122, 118),
    "smoke": (160, 160, 156),
    "smoke_lt": (198, 198, 194),
    "amber": (232, 196, 78),
    "yellow": (226, 208, 92),
    "orange": (212, 122, 40),
    "lred": (208, 78, 56),
    "ours_dk": (48, 82, 116),  # light blue, ours -- matches TERM_L_BLUE
    "ours": (96, 148, 190),
    "ours_lt": (150, 192, 222),
    "theirs_dk": (94, 30, 26),  # the enemy side colour -- matches TERM_RED
    "theirs": (158, 56, 44),
    "theirs_lt": (198, 96, 78),
    "flesh_dk": (146, 108, 78),
    "flesh": (192, 150, 114),
    "wood_dk": (72, 52, 34),
    "wood": (110, 82, 52),
    "wood_lt": (146, 114, 76),
    "magenta_hi": (220, 40, 220),  # the "no tile mapped here" marker
    # 0.9 phase 2: the hedges, the undergrowth and the trees.  Appended, so
    # every colour above keeps its palette index.
    "leaf_dk": (38, 54, 30),
    "leaf": (58, 80, 40),
    "leaf_lt": (88, 112, 58),
    # 0.9 phase 2, fix round 1: the remembered high ground, a darker chalk
    # that only the slope's and the crest's dim twins may use (DIM_ALLOW).
    "chalk_dim_lt": (136, 132, 122),
    "chalk_dim": (114, 110, 101),
    "chalk_dim_dk": (94, 91, 84),
}

PAL_ORDER = list(PAL.keys())
PAL_INDEX = {name: i for i, name in enumerate(PAL_ORDER)}
assert len(PAL_ORDER) <= 256

# --------------------------------------------------------------------------
# A tiny deterministic PRNG, so the sheet is byte-identical on every run.
# --------------------------------------------------------------------------


class Rng:
    def __init__(self, seed):
        self.s = (seed * 2654435761 + 1013904223) & 0xFFFFFFFF

    def next(self):
        self.s = (self.s * 1103515245 + 12345) & 0xFFFFFFFF
        return (self.s >> 8) & 0xFFFFFF

    def below(self, n):
        return self.next() % n

    def pct(self, n):
        return self.below(100) < n

    def pick(self, seq):
        return seq[self.below(len(seq))]


# --------------------------------------------------------------------------
# The canvas.  One byte (palette index) per pixel; "KEY" everywhere to start.
# --------------------------------------------------------------------------
CANVAS = [[PAL_INDEX["KEY"]] * WID for _ in range(HGT)]


class Tile:
    """A 16x16 window onto the sheet, with the drawing primitives."""

    def __init__(self, row, col, seed):
        self.oy = row * TILE
        self.ox = col * TILE
        self.rng = Rng(seed)

    def px(self, x, y, colour):
        if 0 <= x < TILE and 0 <= y < TILE:
            CANVAS[self.oy + y][self.ox + x] = PAL_INDEX[colour]

    def get(self, x, y):
        return CANVAS[self.oy + y][self.ox + x]

    def fill(self, colour):
        for y in range(TILE):
            for x in range(TILE):
                self.px(x, y, colour)

    def rect(self, x0, y0, x1, y1, colour):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                self.px(x, y, colour)

    def hline(self, x0, x1, y, colour):
        for x in range(x0, x1 + 1):
            self.px(x, y, colour)

    def vline(self, x, y0, y1, colour):
        for y in range(y0, y1 + 1):
            self.px(x, y, colour)

    def line(self, x0, y0, x1, y1, colour):
        dx, dy = abs(x1 - x0), abs(y1 - y0)
        sx = 1 if x1 >= x0 else -1
        sy = 1 if y1 >= y0 else -1
        err = dx - dy
        x, y = x0, y0
        while True:
            self.px(x, y, colour)
            if x == x1 and y == y1:
                break
            e2 = 2 * err
            if e2 > -dy:
                err -= dy
                x += sx
            if e2 < dx:
                err += dx
                y += sy

    def disc(self, cx, cy, r, colour, ry=None):
        ry = r if ry is None else ry
        for y in range(TILE):
            for x in range(TILE):
                dx = (x - cx) / float(r)
                dy = (y - cy) / float(ry)
                if dx * dx + dy * dy <= 1.0:
                    self.px(x, y, colour)

    def ring(self, cx, cy, r, colour, ry=None):
        ry = r if ry is None else ry
        for y in range(TILE):
            for x in range(TILE):
                dx = (x - cx) / float(r)
                dy = (y - cy) / float(ry)
                d = dx * dx + dy * dy
                if 0.55 <= d <= 1.0:
                    self.px(x, y, colour)

    def speckle(self, colours, density):
        """Scatter flecks over whatever is already there."""
        for y in range(TILE):
            for x in range(TILE):
                if self.rng.pct(density):
                    self.px(x, y, self.rng.pick(colours))

    def art(self, lines, legend):
        """Paint character art. '.' leaves the pixel alone."""
        for y, row in enumerate(lines):
            for x, ch in enumerate(row):
                if ch == ".":
                    continue
                self.px(x, y, legend[ch])


def dim_tile(src_row, src_col, dst_row, dst_col, factor=0.68, allow=()):
    """Copy a tile, darkened: the 'remembered but not now seen' twin.

    map_info()'s special_lighting_* hooks pick the dim twin by adding 1 to the
    tile's column (the MicroChasm convention), so every terrain tile is laid
    down as a lit/dim PAIR in adjacent columns.  `allow` names the RESTRICTED
    colours this tile's twin may land on (DIM_ALLOW).
    """
    for y in range(TILE):
        for x in range(TILE):
            idx = CANVAS[src_row * TILE + y][src_col * TILE + x]
            name = PAL_ORDER[idx]
            if name == "KEY":
                CANVAS[dst_row * TILE + y][dst_col * TILE + x] = idx
                continue
            r, g, b = PAL[name]
            want = (int(r * factor), int(g * factor), int(b * factor))
            CANVAS[dst_row * TILE + y][dst_col * TILE + x] = nearest(
                want, allow + (GREENS if name in GREENS else ()))


# Colours a darkened pixel lands on only by leave, so that every v8 tile keeps
# exactly the dim twin it had: the 0.9 greens by darkening a green (a dark
# grey's nearest darker match would otherwise be the darkest leaf), and the
# remembered high ground's darker chalk by dimming the slope or the crest.
GREENS = ("leaf_dk", "leaf", "leaf_lt")
HILL_DIMS = ("chalk_dim_lt", "chalk_dim", "chalk_dim_dk")
RESTRICTED = GREENS + HILL_DIMS

_NEAREST_CACHE = {}


def nearest(rgb, allow=()):
    hit = _NEAREST_CACHE.get((rgb, allow))
    if hit is not None:
        return hit
    best, best_d = 0, None
    for i, name in enumerate(PAL_ORDER):
        if name == "KEY":
            continue  # never let a darkened pixel become transparent
        if (name in RESTRICTED) and (name not in allow):
            continue
        pr, pg, pb = PAL[name]
        d = (pr - rgb[0]) ** 2 + (pg - rgb[1]) ** 2 + (pb - rgb[2]) ** 2
        if best_d is None or d < best_d:
            best, best_d = i, d
    _NEAREST_CACHE[(rgb, allow)] = best
    return best


# --------------------------------------------------------------------------
# The catalogue.  Every entry is (row, col, name, kind, drawing function).
# 'kind' is "terrain" (opaque, gets a dim twin in the next column), "thing"
# or "unit" (transparent ground), or "icon".
# --------------------------------------------------------------------------
CATALOGUE = []


def entry(row, col, name, kind, fn):
    CATALOGUE.append((row, col, name, kind, fn))


# ---- ground textures shared by several terrain tiles ---------------------


def ground(t, base="mud"):
    t.fill(base)
    t.speckle(["mud_dk", "mud_lt", "mud_pale"], 26)
    t.speckle(["chalk_dk"], 5)


def crater(t, r, inner, rim, bottom=None):
    ground(t)
    t.disc(8, 8, r, rim)
    t.disc(8, 8, r - 2, inner)
    if bottom:
        t.disc(8, 8, max(1, r - 4), bottom)
    # a lip of thrown-up chalk on the upper left, shadow lower right
    for y in range(TILE):
        for x in range(TILE):
            dx, dy = (x - 8) / float(r), (y - 8) / float(r)
            d = dx * dx + dy * dy
            if 0.80 <= d <= 1.05:
                t.px(x, y, "chalk" if (x + y) < 15 else "shadow")


def sandbag_row(t, y, colour, dark, light, off=0):
    """One course of sandbags, y..y+3."""
    for i in range(-1, 4):
        x = off + i * 5
        t.rect(x, y, x + 4, y + 3, colour)
        t.hline(x, x + 4, y, light)
        t.hline(x, x + 4, y + 3, dark)
        t.vline(x, y, y + 3, dark)


def revetment(t, floor, wall, plank, top, bot):
    """A ditch seen from above: a channel between two sandbagged lips."""
    ground(t)
    t.rect(0, top, 15, bot, wall)
    t.rect(0, top + 1, 15, bot - 1, floor)
    for x in range(1, TILE, 4):
        t.vline(x, top + 1, bot - 1, plank)
    # the sandbagged lips, above and below the ditch
    sandbag_row(t, 0, "sand", "sand_dk", "sand_lt", off=0)
    sandbag_row(t, TILE - 4, "sand", "sand_dk", "sand_lt", off=2)


# ---- row 0: icons and Sil's specials ------------------------------------

FONT3x5 = {
    "0": ["111", "101", "101", "101", "111"],
    "1": ["010", "110", "010", "010", "010"],
    "2": ["111", "001", "111", "100", "111"],
    "3": ["111", "001", "111", "001", "111"],
    "4": ["101", "101", "111", "001", "001"],
    "5": ["111", "100", "111", "001", "111"],
    "6": ["111", "100", "111", "101", "111"],
    "7": ["111", "001", "010", "010", "010"],
    "8": ["111", "101", "111", "101", "111"],
    "9": ["111", "101", "111", "001", "111"],
    "?": ["111", "001", "011", "000", "010"],
}


def make_digit(ch):
    def draw(t):
        rows = FONT3x5[ch]
        for y, row in enumerate(rows):
            for x, bit in enumerate(row):
                if bit == "1":
                    # 3x5 scaled x2, centred, with a dark outline behind
                    for oy in range(2):
                        for ox in range(2):
                            t.px(5 + x * 2 + ox, 3 + y * 2 + oy, "white")
        for y in range(TILE):
            for x in range(TILE):
                if PAL_ORDER[t.get(x, y)] == "white":
                    continue
                near = False
                for dy in (-1, 0, 1):
                    for dx in (-1, 0, 1):
                        if 0 <= x + dx < TILE and 0 <= y + dy < TILE:
                            if PAL_ORDER[t.get(x + dx, y + dy)] == "white":
                                near = True
                if near:
                    t.px(x, y, "black")

    return draw


def draw_none(t):
    """FEAT_NONE: the unknown ground.  Opaque, near-black, faintly grained."""
    t.fill("black")
    t.speckle(["shadow"], 12)


def draw_alert_icon(t):
    """Composited on top of an alert monster.  OTT does not use it (map_info
    skips the alert mask in GRAPHICS_OTT mode) but the loaders read
    misc_to_attr[ICON_ALERT] unconditionally, so it must point at a tile whose
    ground is transparent -- otherwise every alert soldier is painted out.
    That is exactly the bug that forced ASCII on Windows in Feedback1-A."""
    t.vline(13, 2, 6, "white")
    t.px(13, 8, "white")
    t.vline(14, 2, 6, "amber")
    t.px(14, 8, "amber")


def draw_glow_icon(t):
    t.ring(8, 8, 7, "amber")


def draw_unknown_item(t):
    t.rect(4, 4, 11, 11, "steel_dk")
    t.rect(5, 5, 10, 10, "steel")
    t.px(7, 7, "white")


def draw_missing(t):
    """No mapping points here: a loud magenta hatch, so a mistake shows."""
    t.fill("black")
    for y in range(TILE):
        for x in range(TILE):
            if (x + y) % 4 == 0:
                t.px(x, y, "magenta_hi")


# ---- terrain -------------------------------------------------------------


def draw_open(t):
    ground(t)
    # a couple of tufts of what is left of the grass
    for _ in range(3):
        x, y = t.rng.below(14) + 1, t.rng.below(14) + 1
        t.px(x, y, "khaki")
        t.px(x, y - 1, "khaki_dk")


def draw_shellhole(t):
    crater(t, 7, "mud_dk", "mud_lt")
    t.speckle(["shadow"], 8)


def draw_hole_deep(t):
    crater(t, 8, "shadow", "mud_dk", bottom="black")
    t.speckle(["black"], 10)


def draw_hole_flooded(t):
    crater(t, 8, "water_dk", "mud_dk")
    t.disc(8, 8, 5, "water")
    t.hline(4, 11, 6, "water_lt")
    t.hline(5, 10, 9, "water_lt")
    t.px(6, 11, "water_lt")


def draw_trench(t):
    """The DEEP trench: a wide, black ditch you cannot see out of."""
    revetment(t, "black", "wood_dk", "wood_dk", 4, 11)
    t.rect(0, 6, 15, 9, "black")
    t.speckle(["shadow"], 6)


def draw_trench_shallow(t):
    """The SHALLOW trench: a narrow ditch with the floor still in daylight --
    a man in one has his head above the parapet."""
    revetment(t, "mud_dk", "wood", "wood_lt", 5, 10)
    t.hline(0, 15, 7, "mud")
    t.hline(0, 15, 8, "mud")
    t.speckle(["mud_lt"], 8)


def draw_dugout(t):
    ground(t, "mud_dk")
    t.rect(2, 3, 13, 14, "wood_dk")
    t.rect(3, 5, 12, 14, "black")
    t.hline(2, 13, 3, "wood_lt")
    t.hline(2, 13, 4, "wood")
    t.vline(2, 3, 14, "wood")
    t.vline(13, 3, 14, "wood")
    t.px(7, 9, "shadow")


def draw_wire(t):
    """Enemy wire: dense, rusted, and unmistakably a belt."""
    ground(t)
    for k in (-1, 0, 1):
        t.line(0, 3 + 5 * (k + 1) - 3, 15, 3 + 5 * (k + 1) + 2, "rust")
        t.line(15, 3 + 5 * (k + 1) - 3, 0, 3 + 5 * (k + 1) + 2, "rust_dk")
    for _ in range(9):
        x, y = t.rng.below(16), t.rng.below(16)
        t.px(x, y, "rust_lt")
    t.vline(4, 0, 15, "rust_dk")
    t.vline(11, 0, 15, "rust_dk")


def draw_wire_ally(t):
    """Our own wire: the same belt, but new galvanised steel rather than rust,
    and with a lane through the middle our men know about."""
    ground(t)
    for k in (-1, 0, 1):
        t.line(0, 3 + 5 * (k + 1) - 3, 15, 3 + 5 * (k + 1) + 2, "steel")
        t.line(15, 3 + 5 * (k + 1) - 3, 0, 3 + 5 * (k + 1) + 2, "steel_dk")
    for _ in range(9):
        x, y = t.rng.below(16), t.rng.below(16)
        t.px(x, y, "steel_lt")
    t.vline(4, 0, 15, "steel_dk")
    t.vline(11, 0, 15, "steel_dk")
    # the lane: a clear column of trodden ground straight through the belt
    t.vline(7, 0, 15, "mud_pale")
    t.vline(8, 0, 15, "mud_lt")


def draw_parapet(t):
    """Sandbags, stacked and staggered: the wall of the line."""
    t.fill("mud_dk")
    for row in range(4):
        sandbag_row(t, row * 4, "sand", "sand_dk", "sand_lt",
                    off=0 if row % 2 == 0 else 2)
    t.speckle(["sand_dk", "sand_lt"], 8)


def draw_rubble(t):
    t.fill("mud_dk")
    blocks = [(1, 1, 5, 5), (7, 0, 12, 4), (0, 7, 4, 12), (6, 6, 11, 10),
              (12, 6, 15, 11), (2, 12, 8, 15), (10, 12, 15, 15)]
    for i, (x0, y0, x1, y1) in enumerate(blocks):
        c = ["grey", "chalk_dk", "mud_lt", "grey_lt", "chalk"][i % 5]
        t.rect(x0, y0, x1, y1, c)
        t.hline(x0, x1, y0, "chalk_lt")
        t.vline(x1, y0, y1, "shadow")
    t.speckle(["shadow"], 12)


def draw_mgpost(t):
    """A gun emplacement: a sandbag horseshoe with the muzzle in the slit."""
    draw_parapet(t)
    t.rect(3, 5, 12, 12, "shadow")
    t.rect(4, 6, 11, 11, "mud_dk")
    t.rect(5, 7, 10, 8, "steel_dk")
    t.hline(2, 13, 9, "steel")
    t.px(1, 9, "steel_lt")
    t.px(0, 9, "steel_lt")
    t.rect(6, 10, 9, 11, "steel_dk")


def draw_objective(t):
    """The briefing's mark: a shallow trench tile with a white stake on it."""
    draw_trench_shallow(t)
    t.vline(7, 2, 13, "white")
    t.vline(8, 2, 13, "chalk_dk")
    t.rect(9, 2, 13, 6, "white")
    t.rect(10, 3, 12, 5, "red")


def draw_butterfly(t):
    draw_parapet(t)
    legend = {"y": "yellow", "k": "black", "o": "orange"}
    t.art(
        [
            "................",
            "................",
            "................",
            "................",
            "....yy....yy....",
            "...yyyy..yyyy...",
            "..yyyyykkyyyyy..",
            "..yyoyykkyyoyy..",
            "...yyyykkyyyy...",
            "....yyykkyyy....",
            ".....yykkyy.....",
            "......ykky......",
            "................",
            "................",
            "................",
            "................",
        ],
        legend,
    )


def draw_mist(t):
    t.fill("smoke_dk")
    for cx, cy, r in ((4, 5, 4), (11, 4, 3), (7, 11, 5), (13, 12, 3)):
        t.disc(cx, cy, r, "smoke")
        t.disc(cx, cy, max(1, r - 2), "smoke_lt")
    t.speckle(["smoke_lt", "smoke_dk"], 18)


def draw_sil_floor(t):
    t.fill("grey_dk")
    t.rect(1, 1, 14, 14, "grey")
    t.speckle(["grey_lt", "grey_dk"], 14)


def draw_sil_wall(t):
    t.fill("grey_dk")
    for row in range(4):
        y = row * 4
        off = 0 if row % 2 == 0 else 4
        for i in range(-1, 3):
            x = off + i * 8
            t.rect(x, y, x + 6, y + 2, "grey")
            t.hline(x, x + 6, y, "grey_lt")
    t.speckle(["grey_dk"], 8)


def draw_cut_gap(t):
    """A lane cut through the belt: the wire's cut ends, and clear ground
    between them.  RESERVED -- a cut gap is FEAT_OTT_OPEN today, so nothing
    maps here yet (see dev/v8/D.md)."""
    ground(t)
    for y in (2, 4, 12, 14):
        t.hline(0, 3, y, "rust")
        t.hline(12, 15, y, "rust")
        t.px(4, y, "rust_lt")
        t.px(11, y, "rust_lt")
    t.hline(0, 15, 8, "mud_pale")


def draw_duckboard(t, deep):
    """RESERVED for group B's duckboard trench variants: raised wooden slats
    over the trench floor."""
    if deep:
        draw_trench(t)
    else:
        draw_trench_shallow(t)
    for y in range(4, 12, 2):
        t.hline(1, 14, y, "wood_lt")
        t.hline(1, 14, y + 1, "wood")
    t.vline(1, 4, 11, "wood_dk")
    t.vline(14, 4, 11, "wood_dk")


# ---- 0.9: high ground (group C, M11) --------------------------------------
# Open ground on a rise, drawn for the per-tile height under FEAT_OTT_OPEN
# (ott_hill_glyph(), cave.c) -- the ASCII 'o' / 'O' in light grey.  The pale
# chalk of the rises is the family; the hatching says "slope", its absence on
# the paler ground says "crest".


def tufts(t, n, colour="khaki", dark="khaki_dk"):
    for _ in range(n):
        x, y = t.rng.below(14) + 1, t.rng.below(14) + 1
        t.px(x, y, colour)
        t.px(x, y - 1, dark)


def draw_slope(t):
    """A slope, height 1: chalky ground, hatched with the map-maker's
    short downhill strokes."""
    t.fill("chalk_dk")
    t.speckle(["smoke_dk", "mud_pale", "grey_lt"], 28)
    t.speckle(["mud_lt"], 4)
    for row, y in enumerate((1, 5, 9, 13)):
        for x in range(1 if row % 2 == 0 else 3, TILE, 4):
            t.vline(x, y, y + 1, "mud_dk")
    tufts(t, 2)


def draw_crest(t):
    """A crest, height 2: the top of the rise -- paler again, and no
    hatching, because nothing here falls away."""
    t.fill("chalk")
    t.speckle(["chalk_lt", "smoke", "smoke_lt"], 28)
    t.speckle(["chalk_dk"], 6)
    tufts(t, 3)


# High ground is known from the start, so it is drawn remembered for most of a
# battle: its dim twins stay in the grey family (the ASCII 'o' / 'O' dim to dark
# grey) by darkening to the darker chalk no other tile may use.
DIM_ALLOW = {draw_slope: HILL_DIMS, draw_crest: HILL_DIMS}


# ---- 0.9 phase 2: the new battles' ground (FEAT_OTT_BRICK..FEAT_OTT_TREE) --


def brickwork(t):
    """Courses of weathered brick, two pixels high, in a running bond."""
    t.fill("mud_pale")
    for course in range(6):
        y = course * 3
        off = 0 if course % 2 == 0 else 3
        for i in range(-1, 4):
            x0 = off + i * 6
            c = t.rng.pick(["rust", "rust", "rust", "rust_lt", "rust_dk"])
            t.rect(x0, y, x0 + 4, y + 1, c)
            t.hline(x0, x0 + 4, y, "rust_lt" if c != "rust_lt" else "sand")
    t.speckle(["rust_dk", "mud_dk"], 6)


def draw_brick(t):
    """A brick wall -- a house, a farm, the church."""
    brickwork(t)
    # a shell scar: a few bricks knocked out
    t.rect(10, 9, 12, 10, "shadow")
    t.px(9, 10, "mud_dk")
    t.px(13, 9, "mud_dk")


def draw_loophole(t):
    """A loophole in the wall: a steel plate with the slit in it."""
    brickwork(t)
    t.rect(4, 4, 11, 11, "steel_dk")
    t.rect(5, 5, 10, 10, "steel")
    t.hline(5, 10, 5, "steel_lt")
    t.rect(7, 6, 8, 10, "black")
    t.px(5, 10, "steel_dk")
    t.px(10, 10, "steel_dk")


def draw_floor(t):
    """The floor of a ruined house: big flags under plaster dust and roof
    tiles, open to the sky."""
    t.fill("grey_dk")
    flags = [(0, 0, 6, 6), (8, 0, 15, 6), (-4, 8, 2, 15), (4, 8, 10, 15),
             (12, 8, 18, 15)]
    for x0, y0, x1, y1 in flags:
        c = t.rng.pick(["chalk_dk", "smoke_dk", "chalk_dk", "grey_lt"])
        t.rect(x0, y0, x1, y1, c)
        t.hline(x0, x1, y0, "chalk")
    t.speckle(["chalk_lt", "chalk"], 10)
    for x, y in ((3, 4), (12, 11), (6, 13)):
        t.px(x, y, "rust")
        t.px(x + 1, y, "rust_dk")
    t.line(9, 3, 12, 4, "wood_lt")


def bush(t, cx, cy, r):
    t.disc(cx, cy, r, "leaf_dk")
    t.disc(cx - 1, cy - 1, max(1, r - 1), "leaf")
    t.px(cx - 1, cy - 2, "leaf_lt")
    t.px(cx - 2, cy - 1, "leaf_lt")


def draw_hedge(t):
    """A hedge: thick, low and green, and nothing seen through it."""
    t.fill("leaf_dk")
    for cx, cy, r in ((3, 3, 3), (9, 2, 3), (14, 4, 3), (5, 8, 3),
                      (11, 8, 3), (2, 13, 3), (8, 13, 3), (14, 12, 3)):
        bush(t, cx, cy, r)
    t.speckle(["shadow"], 6)
    for x, y in ((7, 5), (12, 15), (1, 9)):
        t.px(x, y, "wood_dk")


def draw_emplacement(t):
    """A covered gun emplacement: the MG post with a roof of baulks over the
    gun, and only the muzzle showing in the slit."""
    draw_parapet(t)
    t.rect(3, 4, 13, 12, "wood_dk")
    for y in (4, 7, 10):
        t.rect(3, y, 13, y + 1, "wood")
        t.hline(3, 13, y, "wood_lt")
    t.rect(1, 7, 3, 9, "black")
    t.hline(0, 3, 8, "steel")
    t.px(0, 8, "steel_lt")


def draw_road(t):
    """A road or a street: cobbled setts, some of them lifted."""
    t.fill("mud_dk")
    for row in range(4):
        y = row * 4
        off = 0 if row % 2 == 0 else 2
        for i in range(-1, 5):
            x = off + i * 4
            if t.rng.pct(8):
                continue  # a sett lifted: mud
            c = t.rng.pick(["grey", "grey", "smoke_dk", "grey_lt"])
            t.rect(x, y, x + 2, y + 2, c)
            t.px(x, y, "smoke")
            t.px(x + 2, y + 2, "grey_dk")
    t.speckle(["mud", "mud_lt"], 5)


def thick(t, x0, y0, x1, y1, r, colour):
    """Every pixel within r of the segment (x0,y0)-(x1,y1)."""
    dx, dy = x1 - x0, y1 - y0
    n = float(dx * dx + dy * dy) or 1.0
    for y in range(TILE):
        for x in range(TILE):
            k = max(0.0, min(1.0, ((x - x0) * dx + (y - y0) * dy) / n))
            ex, ey = x0 + k * dx - x, y0 + k * dy - y
            if ex * ex + ey * ey <= r * r:
                t.px(x, y, colour)


def trunk(t, x0, y0, x1, y1):
    """A felled trunk: dark outline, bark, the light along its top."""
    thick(t, x0, y0, x1, y1, 2.1, "shadow")
    thick(t, x0, y0, x1, y1, 1.3, "wood")
    t.line(x0, y0 - 1, x1, y1 - 1, "wood_lt")
    t.line(x0, y0 + 1, x1, y1 + 1, "wood_dk")


def draw_barricade(t):
    """A street barricade: sandbags, a beam and a cart wheel piled across the
    road -- seen over, never crossed."""
    draw_road(t)
    sandbag_row(t, 8, "sand", "sand_dk", "sand_lt", off=1)
    sandbag_row(t, 12, "sand", "sand_dk", "sand_lt", off=3)
    t.disc(5, 5, 5, "shadow")
    t.ring(5, 5, 4, "wood_lt")
    t.line(5, 2, 5, 8, "wood")
    t.line(2, 5, 8, 5, "wood")
    t.rect(4, 4, 6, 6, "wood_dk")
    t.px(5, 5, "wood_lt")
    trunk(t, 9, 7, 15, 1)


def draw_tower(t):
    """The church tower from above: a stone parapet round a slate spire,
    with the cross at its point."""
    t.fill("chalk")
    for y in (0, 5, 10, 15):
        t.hline(0, 15, y, "chalk_dk")
    for x in (3, 9, 14):
        t.vline(x, 0, 15, "chalk_dk")
    for y in range(2, 14):
        for x in range(2, 14):
            dx, dy = x - 7.5, y - 7.5
            if abs(dy) >= abs(dx):
                c = "steel" if dy < 0 else "grey_dk"
            else:
                c = "steel_dk" if dx < 0 else "shadow"
            t.px(x, y, c)
    t.line(2, 2, 13, 13, "steel_lt")
    t.line(13, 2, 2, 13, "steel_lt")
    t.vline(7, 5, 9, "white")
    t.hline(6, 8, 6, "white")


def draw_graves(t):
    """A churchyard: headstones and a cross over the mounds."""
    ground(t)
    tufts(t, 4)
    for x0, y0 in ((1, 2), (6, 8)):
        t.rect(x0, y0 + 4, x0 + 4, y0 + 6, "mud_lt")
        t.rect(x0 + 1, y0, x0 + 3, y0 + 3, "chalk")
        t.hline(x0 + 1, x0 + 3, y0, "chalk_lt")
        t.vline(x0 + 3, y0 + 1, y0 + 3, "chalk_dk")
    t.rect(10, 9, 14, 11, "mud_lt")
    t.vline(12, 1, 8, "chalk_lt")
    t.hline(10, 14, 3, "chalk_lt")
    t.vline(13, 2, 8, "chalk_dk")


def draw_undergrowth(t):
    """Undergrowth: bramble and scrub in clumps, the mud between them."""
    ground(t)
    for cx, cy, r in ((4, 4, 3), (12, 6, 3), (6, 12, 3), (13, 13, 2)):
        bush(t, cx, cy, r)
    for (x0, y0, x1, y1) in ((7, 3, 10, 9), (1, 9, 4, 14), (9, 11, 15, 9)):
        t.line(x0, y0, x1, y1, "wood_dk")


def draw_abatis(t):
    """An abatis: felled trees laid crossed, their sharpened ends out, with
    the wire woven through the branches."""
    ground(t)
    trunk(t, 2, 2, 13, 13)
    trunk(t, 2, 13, 13, 2)
    for x, y in ((1, 1), (14, 1), (1, 14), (14, 14)):
        t.px(x, y, "sand_lt")
    t.line(0, 7, 15, 9, "rust_lt")
    t.line(0, 10, 15, 6, "rust")
    for x, y in ((3, 7), (12, 8), (6, 9), (10, 7)):
        t.px(x, y - 1, "rust_lt")
        t.px(x, y + 1, "rust_dk")


def wattle(t, y0, y1):
    """A woven hurdle, the revetment of a breastwork."""
    for y in range(y0, y1 + 1):
        for x in range(TILE):
            t.px(x, y, "wood" if ((x // 2 + y) % 2 == 0) else "wood_dk")
    t.hline(0, 15, y0, "wood_lt")


def draw_breastwork(t):
    """The firing position behind a breastwork (the Wood's line): the
    shallow trench's layout, but built up out of hurdles and brushwood on
    ground too wet to dig."""
    ground(t, "mud_dk")
    t.rect(0, 5, 15, 10, "wood_dk")
    t.rect(0, 6, 15, 9, "mud")
    for x in range(1, TILE, 4):
        t.vline(x, 6, 9, "wood_lt")
    t.speckle(["mud_lt"], 8)
    wattle(t, 0, 3)
    wattle(t, 12, 15)


def draw_stump(t):
    """A fallen tree and the stump it broke from: splintered, climbable,
    some cover."""
    ground(t)
    trunk(t, 4, 13, 15, 8)
    t.rect(3, 12, 4, 14, "sand_lt")
    thick(t, 9, 10, 10, 6, 0.8, "wood_dk")
    # the stump, shattered: bark round a split, splintered top
    t.disc(5, 5, 4, "shadow")
    t.disc(5, 5, 3, "wood_dk")
    for x, y in ((4, 3), (5, 4), (6, 5), (4, 6), (6, 3), (3, 5), (5, 6),
                 (7, 4)):
        t.px(x, y, "sand")
    for x, y in ((2, 1), (5, 0), (8, 2), (1, 4), (9, 6)):
        t.line(x, y, 5, 5, "wood_lt")
        t.px(x, y, "sand_lt")


def draw_bank(t):
    """The breastwork's bank: earth built up behind a wall of logs, staked --
    our parapet's rules."""
    t.fill("mud_dk")
    for row in range(4):
        y = row * 4
        t.rect(0, y, 15, y + 2, "wood_dk")
        t.hline(0, 15, y + 1, "wood")
        t.hline(0, 15, y, "wood_lt" if row % 2 == 0 else "wood")
        t.px(t.rng.below(16), y + 1, "wood_lt")
    for x in (4, 11):
        t.vline(x, 0, 15, "shadow")
    t.speckle(["mud", "mud_lt"], 6)


def draw_tree(t):
    """A tree: a crown nothing walks or sees through."""
    ground(t, "mud_dk")
    t.disc(8, 9, 7, "shadow")
    t.disc(7, 7, 7, "leaf_dk")
    for cx, cy, r in ((5, 5, 3), (10, 5, 3), (6, 10, 3), (11, 10, 3),
                      (8, 7, 3)):
        t.disc(cx, cy, r, "leaf")
        t.px(cx - 1, cy - 1, "leaf_lt")
        t.px(cx, cy - 2, "leaf_lt")
        t.px(cx - 2, cy, "leaf_lt")
        t.px(cx + 1, cy + 2, "leaf_dk")
    for x, y in ((8, 4), (4, 8), (9, 9), (12, 7)):
        t.px(x, y, "shadow")


# ---- things (transparent ground) ----------------------------------------

CORPSE_ART = [
    "................",
    "................",
    "................",
    "................",
    ".....hhh........",
    "....hfffh.......",
    ".....fff........",
    "...UUUUUUUUu....",
    "..uUUUUUUUUUu...",
    "...uUUUUUUUu....",
    "....u.....u.....",
    "..bb.......bb...",
    "................",
    "................",
    "................",
    "................",
]


def make_corpse(side):
    def draw(t):
        legend = {
            "h": "steel_dk",
            "f": "flesh_dk",
            "U": "ours" if side == "ours" else "theirs",
            "u": "ours_dk" if side == "ours" else "theirs_dk",
            "b": "wood_dk",
        }
        t.art(CORPSE_ART, legend)
        # a stain under him: he has been there a while
        t.px(6, 10, "blood_dk")
        t.px(9, 10, "blood_dk")

    return draw


def draw_corpse_old(t):
    """0.9 (M21): one of the dead of an earlier attack -- gone the colour of
    the ground he lies on, sunk into it, the bone showing and the helmet
    rusted.  Nothing of either side's colour is left on him."""
    legend = {"o": "shadow", "S": "mud_pale", "s": "mud_lt", "B": "chalk",
              "b": "chalk_dk", "k": "black", "r": "rust_dk", "R": "rust"}
    t.art(
        [
            "................",
            "................",
            "................",
            "..ooo...........",
            ".oRRro..........",
            ".orrro.oooo.....",
            "..ooo.oBBBBo....",
            "......oBkBkBo...",
            "......oBBBBo....",
            "....ooooBbooooo.",
            "...oSBsBsBsSSSso",
            "...oSsBsBsSSsSo.",
            "....oSSSSSSsSo..",
            ".....oo.oSSoo...",
            "........oo......",
            "................",
        ],
        legend,
    )


def draw_gun(t):
    """The abandoned machine gun: a gun on its tripod, nobody behind it."""
    legend = {"s": "steel", "d": "steel_dk", "l": "steel_lt", "y": "amber",
              "k": "black"}
    t.art(
        [
            "................",
            "................",
            "......dd........",
            ".....dssd.......",
            "lllllsssdd......",
            "llllldssssd.....",
            "......dssssd....",
            ".......dsssd....",
            "........dsd.....",
            ".......ddsdd....",
            "......d..s..d...",
            ".....d...s...d..",
            "....d....s....d.",
            "...k.....k.....k",
            "................",
            "................",
        ],
        legend,
    )
    t.px(2, 4, "amber")
    t.px(3, 5, "amber")


def draw_smoke(t):
    """Smoke and cloud: thick enough to hide the ground under it, with the
    edges torn -- the transparent gaps are what makes it read as smoke."""
    for cx, cy, r, c in ((5, 5, 4, "smoke"), (10, 4, 3, "smoke_lt"),
                         (7, 10, 5, "smoke"), (12, 11, 3, "smoke_dk"),
                         (3, 11, 3, "smoke_lt")):
        t.disc(cx, cy, r, c)
    t.speckle(["smoke_lt", "smoke_dk"], 14)
    # tear the border so the ground shows round the edges
    for y in range(TILE):
        for x in range(TILE):
            edge = min(x, y, 15 - x, 15 - y)
            if edge == 0 and t.rng.pct(70):
                t.px(x, y, "KEY")
            elif edge == 1 and t.rng.pct(35):
                t.px(x, y, "KEY")


def make_flash(inner, outer):
    def draw(t):
        t.disc(8, 8, 5, outer)
        t.disc(8, 8, 3, inner)
        for (dx, dy) in ((1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1),
                         (-1, 1), (-1, -1)):
            for k in range(4, 8):
                t.px(8 + dx * k, 8 + dy * k, outer)
        t.px(8, 8, "white")
        t.px(7, 8, "white")
        t.px(8, 7, "white")

    return draw


def draw_grenade(t):
    """The bomb in flight: a small iron ball with the fuse smoking."""
    t.disc(7, 9, 4, "steel_dk")
    t.disc(7, 9, 3, "steel")
    t.px(6, 8, "steel_lt")
    t.vline(10, 3, 5, "steel_dk")
    t.px(11, 3, "amber")
    t.px(12, 2, "orange")
    t.px(12, 1, "smoke_lt")
    # the segmentation of a Mills bomb
    t.hline(4, 10, 9, "steel_dk")
    t.vline(7, 6, 12, "steel_dk")


def draw_impact(t):
    """A shell arriving: black earth going up, fire at the root of it."""
    t.disc(8, 11, 5, "mud_dk", ry=3)
    t.disc(8, 11, 3, "black", ry=2)
    t.disc(8, 10, 3, "orange", ry=2)
    t.disc(8, 10, 2, "amber", ry=1)
    for x, y in ((2, 6), (4, 3), (6, 1), (9, 2), (12, 4), (14, 7), (5, 6),
                 (11, 6)):
        t.px(x, y, "mud_dk")
        t.px(x, y + 1, "shadow")
    t.px(8, 8, "white")


def make_dot(colour, halo):
    """A dot: small, bright, and clearly ON TOP of the ground rather than
    part of it -- the transparent ground round it does that."""

    def draw(t):
        t.disc(8, 8, 2, halo)
        t.disc(8, 8, 1, colour)
        t.px(8, 8, "white" if colour in ("silver", "white") else colour)

    return draw


def make_wounded(side):
    """The man who has stopped: down, propped, and not fighting.  Same side
    colour as he had standing -- ours or theirs is still the first thing to
    know about him."""

    def draw(t):
        uni = "ours" if side == "ours" else "theirs"
        dk = "ours_dk" if side == "ours" else "theirs_dk"
        legend = {"h": "steel_dk", "f": "flesh", "U": uni, "u": dk,
                  "r": "blood", "b": "wood_dk"}
        t.art(
            [
                "................",
                "................",
                "................",
                "................",
                "..........hhh...",
                ".........hfffh..",
                "..........fff...",
                "....uUUUUUUUu...",
                "...uUUUrUUUUu...",
                "...uUUUrrUUu....",
                "..uUUUUUUUu.....",
                "..bb....bb......",
                "................",
                "................",
                "................",
                "................",
            ],
            legend,
        )

    return draw


def draw_objective_marker(t):
    t.vline(4, 1, 14, "chalk_lt")
    t.vline(5, 1, 14, "chalk_dk")
    t.rect(6, 1, 13, 6, "white")
    t.rect(7, 2, 12, 5, "red")
    t.hline(2, 7, 14, "shadow")


def make_streak(kind):
    def draw(t):
        if kind == "impact":
            t.disc(8, 8, 3, "amber")
            t.disc(8, 8, 2, "white")
            for d in range(4, 7):
                for (dx, dy) in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    t.px(8 + dx * d, 8 + dy * d, "amber")
        elif kind == "vert":
            t.vline(7, 1, 14, "silver")
            t.vline(8, 2, 13, "white")
        elif kind == "horiz":
            t.hline(1, 14, 7, "silver")
            t.hline(2, 13, 8, "white")
        elif kind == "slash":
            t.line(1, 14, 14, 1, "silver")
            t.line(2, 14, 14, 2, "white")
        else:  # backslash
            t.line(1, 1, 14, 14, "silver")
            t.line(1, 2, 13, 14, "white")

    return draw


# ---- units (transparent ground) -----------------------------------------

MAN_ART = [
    "................",
    ".....HHHHHH.....",
    "....HHHHHHHH....",
    "....HffffffH....",
    ".....ffffff.....",
    "......ffff......",
    "....UUUUUUUU.R..",
    "...UUUUUUUUURR..",
    "...uUUUUUUUuR...",
    "...uUUUUUUUR....",
    "....UUUUUUR.....",
    "....uU..Uu......",
    "....uU..Uu......",
    "....bb..bb......",
    "................",
    "................",
]


def make_man(uniform, uni_dk, helmet, extra=None, rifle="wood"):
    def draw(t):
        legend = {
            "H": helmet,
            "f": "flesh",
            "U": uniform,
            "u": uni_dk,
            "R": rifle,
            "b": "wood_dk",
        }
        t.art(MAN_ART, legend)
        if extra:
            extra(t)

    return draw


def mark_player(t):
    """The player: a white outline all round him, so he is never in doubt."""
    for y in range(TILE):
        for x in range(TILE):
            if PAL_ORDER[t.get(x, y)] != "KEY":
                continue
            near = False
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                xx, yy = x + dx, y + dy
                if 0 <= xx < TILE and 0 <= yy < TILE:
                    if PAL_ORDER[t.get(xx, yy)] != "KEY":
                        near = True
            if near:
                t.px(x, y, "white")


def mark_nco(t):
    """Three chevrons on the sleeve."""
    for k in range(3):
        t.px(3, 8 + k, "white")
        t.px(4, 9 + k, "white")


def mark_officer(t):
    """A soft cap and a pistol instead of a rifle: no helmet, and pips."""
    t.rect(4, 1, 11, 3, "khaki_dk")
    t.hline(3, 12, 3, "khaki_lt")
    t.rect(12, 7, 13, 9, "KEY")
    t.rect(12, 8, 13, 9, "steel")
    t.px(5, 7, "amber")
    t.px(10, 7, "amber")


def mark_gunner(t):
    """Behind the gun: the tripod and barrel in front of him."""
    t.hline(0, 6, 11, "steel")
    t.hline(0, 6, 12, "steel_dk")
    t.px(0, 11, "steel_lt")
    t.vline(7, 11, 14, "steel_dk")
    t.px(6, 14, "black")
    t.px(8, 14, "black")


def build():
    """Lay the whole sheet out."""
    # ---- row 0: the reserved blank, darkness, icons, digits, streaks -----
    entry(0, 0, "RESERVED transparency key (never mapped)", "icon",
          lambda t: t.fill("KEY"))
    entry(0, 1, "FEAT_NONE / unknown ground", "terrain-single", draw_none)
    entry(0, 2, "ICON_ALERT overlay", "icon", draw_alert_icon)
    entry(0, 3, "ICON_GLOW overlay", "icon", draw_glow_icon)
    for d in range(10):
        entry(0, 4 + d, "digit %d" % d, "icon", make_digit(str(d)))
    entry(0, 14, "question mark", "icon", make_digit("?"))
    entry(0, 15, "unknown item", "icon", draw_unknown_item)
    entry(0, 16, "bullet impact", "thing", make_streak("impact"))
    entry(0, 17, "bullet streak, vertical", "thing", make_streak("vert"))
    entry(0, 18, "bullet streak, horizontal", "thing", make_streak("horiz"))
    entry(0, 19, "bullet streak, '/'", "thing", make_streak("slash"))
    entry(0, 20, "bullet streak, '\\'", "thing", make_streak("back"))
    for c in range(21, COLS):
        entry(0, c, "unused", "icon", draw_missing)

    # ---- rows 1-2: terrain, in lit/dim pairs ----------------------------
    terrain = [
        ("FEAT_OTT_OPEN open ground", draw_open),
        ("FEAT_OTT_SHELLHOLE shell hole", draw_shellhole),
        ("FEAT_OTT_HOLE_DEEP deep shell hole", draw_hole_deep),
        ("FEAT_OTT_HOLE_FLOODED flooded shell hole", draw_hole_flooded),
        ("FEAT_OTT_TRENCH deep trench", draw_trench),
        ("FEAT_OTT_TRENCH_SHALLOW shallow trench", draw_trench_shallow),
        ("FEAT_OTT_DUGOUT dugout", draw_dugout),
        ("FEAT_OTT_WIRE enemy wire", draw_wire),
        ("FEAT_OTT_WIRE_ALLY allied wire", draw_wire_ally),
        ("FEAT_OTT_PARAPET parapet", draw_parapet),
        ("FEAT_OTT_RUBBLE rubble", draw_rubble),
        ("FEAT_OTT_MGPOST MG post", draw_mgpost),
        ("FEAT_OTT_OBJECTIVE objective", draw_objective),
        ("FEAT_OTT_BUTTERFLY butterfly", draw_butterfly),
        ("FEAT_OTT_MIST mist / edge smoke", draw_mist),
        ("FEAT_FLOOR Sil floor fallback", draw_sil_floor),
    ]
    for i, (name, fn) in enumerate(terrain):
        entry(1, i * 2, name, "terrain", fn)

    row2 = [
        ("FEAT_WALL_* Sil wall fallback", draw_sil_wall),
        ("RESERVED cut gap through wire", draw_cut_gap),
        ("duckboard deep trench (FEAT_OTT_TRENCH_DUCK)", lambda t: draw_duckboard(t, True)),
        ("duckboard shallow trench (FEAT_OTT_TRENCH_SHALLOW_DUCK)",
         lambda t: draw_duckboard(t, False)),
        ("OTT_TILE_SLOPE high ground, a slope (height 1)", draw_slope),
        ("OTT_TILE_CREST high ground, a crest (height 2)", draw_crest),
    ]
    for i, (name, fn) in enumerate(row2):
        entry(2, i * 2, name, "terrain", fn)
    for c in range(len(row2) * 2, COLS):
        entry(2, c, "unused terrain slot", "icon", draw_missing)

    # ---- row 3: things --------------------------------------------------
    things = [
        ("corpse, ours", make_corpse("ours")),
        ("corpse, theirs", make_corpse("theirs")),
        ("abandoned machine gun", draw_gun),
        ("smoke / cloud", draw_smoke),
        ("burst flash, centre", make_flash("white", "amber")),
        ("burst flash, orange", make_flash("amber", "orange")),
        ("burst flash, light red", make_flash("orange", "lred")),
        ("grenade in flight", draw_grenade),
        ("shell impact", draw_impact),
        ("shot dot, silver", make_dot("silver", "steel_dk")),
        ("MG dot, bright", make_dot("white", "steel")),
        ("MG dot, dim", make_dot("steel_dk", "shadow")),
        ("wound dot, red", make_dot("red", "blood_dk")),
        ("wound dot, yellow", make_dot("yellow", "rust_dk")),
        ("wounded man, ours", make_wounded("ours")),
        ("wounded man, theirs", make_wounded("theirs")),
        ("objective marker", draw_objective_marker),
        ("OTT_TILE_CORPSE_OLD corpse, one of the old dead", draw_corpse_old),
    ]
    for i, (name, fn) in enumerate(things):
        entry(3, i, name, "thing", fn)
    for c in range(len(things), COLS):
        entry(3, c, "unused thing slot", "icon", draw_missing)

    # ---- row 4: units --------------------------------------------------
    units = [
        ("the player", make_man("ours", "ours_dk", "steel_lt", mark_player)),
        ("allied rifleman (r_info 342)",
         make_man("ours", "ours_dk", "steel")),
        ("allied NCO (r_info 343)",
         make_man("ours", "ours_dk", "steel_lt", mark_nco)),
        ("RESERVED allied officer",
         make_man("ours", "ours_dk", "steel", mark_officer)),
        ("RESERVED allied machine gunner",
         make_man("ours", "ours_dk", "steel", mark_gunner)),
        ("enemy rifleman (r_info 341)",
         make_man("theirs", "theirs_dk", "grey")),
        ("RESERVED enemy NCO",
         make_man("theirs", "theirs_dk", "grey_lt", mark_nco)),
        ("RESERVED enemy officer",
         make_man("theirs", "theirs_dk", "grey", mark_officer)),
        ("enemy machine gunner (r_info 340)",
         make_man("theirs", "theirs_dk", "grey", mark_gunner)),
    ]
    for i, (name, fn) in enumerate(units):
        entry(4, i, name, "unit", fn)
    for c in range(len(units), COLS):
        entry(4, c, "unused unit slot", "icon", draw_missing)

    # ---- row 5: the new battles' ground (0.9 phase 2), lit/dim pairs ----
    ground09 = [
        ("FEAT_OTT_BRICK brick wall", draw_brick),
        ("FEAT_OTT_LOOPHOLE loophole", draw_loophole),
        ("FEAT_OTT_FLOOR floor of a ruined building", draw_floor),
        ("FEAT_OTT_HEDGE hedge", draw_hedge),
        ("FEAT_OTT_EMPLACEMENT covered emplacement", draw_emplacement),
        ("FEAT_OTT_ROAD road or street", draw_road),
        ("FEAT_OTT_BARRICADE barricade", draw_barricade),
        ("FEAT_OTT_TOWER church tower", draw_tower),
        ("FEAT_OTT_GRAVES churchyard graves", draw_graves),
        ("FEAT_OTT_UNDERGROWTH undergrowth", draw_undergrowth),
        ("FEAT_OTT_ABATIS abatis", draw_abatis),
        ("FEAT_OTT_BREASTWORK breastwork, the firing position",
         draw_breastwork),
        ("FEAT_OTT_STUMP fallen tree or stump", draw_stump),
        ("FEAT_OTT_BREASTWORK_BANK breastwork parapet, the bank", draw_bank),
        ("FEAT_OTT_TREE tree", draw_tree),
    ]
    for i, (name, fn) in enumerate(ground09):
        entry(5, i * 2, name, "terrain", fn)
    for c in range(len(ground09) * 2, COLS):
        entry(5, c, "unused terrain slot", "icon", draw_missing)

    # ---- draw ----------------------------------------------------------
    for row, col, name, kind, fn in CATALOGUE:
        t = Tile(row, col, seed=row * 1000 + col * 7 + 3)
        fn(t)

    # ---- the dim twins -------------------------------------------------
    for row, col, name, kind, fn in list(CATALOGUE):
        if kind == "terrain":
            dim_tile(row, col, row, col + 1, allow=DIM_ALLOW.get(fn, ()))


# --------------------------------------------------------------------------
# Writers
# --------------------------------------------------------------------------


def write_bmp(path):
    """8-bit palettised BMP, BI_RGB, bottom-up, full 256-entry colour table.

    bfOffBits is 54 + 256*4 = 1078, which is what maid-x11.c's
    ncol = (bfOffBits - 54) / 4 expects, and the row stride is the width (512),
    already a multiple of 4 -- that reader does not skip BMP row padding.
    """
    stride = WID
    assert stride % 4 == 0, "width must be a multiple of 4 for the X11 reader"
    pal = bytearray()
    for i in range(256):
        if i < len(PAL_ORDER):
            r, g, b = PAL[PAL_ORDER[i]]
        else:
            r = g = b = 0
        pal += bytes((b, g, r, 0))
    bits = bytearray()
    for y in range(HGT - 1, -1, -1):  # BMP is bottom-up
        bits += bytes(CANVAS[y])
    off = 14 + 40 + len(pal)
    fh = b"BM" + struct.pack("<IHHI", off + len(bits), 0, 0, off)
    ih = struct.pack("<IiiHHIIiiII", 40, WID, HGT, 1, 8, 0, len(bits),
                     3779, 3779, 256, 0)
    with open(path, "wb") as f:
        f.write(fh + ih + pal + bits)


def write_png(path):
    """8-bit RGBA PNG: the magic transparency colour becomes alpha 0, which is
    what main-cocoa.m's create_angband_image()/rage shader expect."""
    key = PAL_INDEX["KEY"]
    raw = bytearray()
    for y in range(HGT):
        raw.append(0)  # filter type 0
        for idx in CANVAS[y]:
            if idx == key:
                raw += b"\x00\x00\x00\x00"
            else:
                r, g, b = PAL[PAL_ORDER[idx]]
                raw += bytes((r, g, b, 255))

    def chunk(tag, data):
        return (struct.pack(">I", len(data)) + tag + data
                + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))

    ihdr = struct.pack(">IIBBBBB", WID, HGT, 8, 6, 0, 0, 0)
    with open(path, "wb") as f:
        f.write(b"\x89PNG\r\n\x1a\n")
        f.write(chunk(b"IHDR", ihdr))
        f.write(chunk(b"IDAT", zlib.compress(bytes(raw), 9)))
        f.write(chunk(b"IEND", b""))


def print_table():
    print("| tile | attr/char | what it is |")
    print("|---|---|---|")
    for row, col, name, kind, fn in CATALOGUE:
        if name in ("unused", "spare", "unused terrain slot",
                    "unused thing slot", "unused unit slot"):
            continue
        print("| r%d c%d | 0x%02X/0x%02X | %s%s |"
              % (row, col, 0x80 + row, 0x80 + col, name,
                 " (dim twin at c%d)" % (col + 1) if kind == "terrain" else ""))


def check():
    """Geometry and convention checks, so a bad edit fails loudly."""
    errs = []
    if WID % 4:
        errs.append("width %d is not a multiple of 4" % WID)
    if ROWS > 64 or COLS > 64:
        errs.append("more than 64 rows/columns: attr/char masks are & 0x3F")
    key = PAL_INDEX["KEY"]
    for y in range(TILE):
        for x in range(TILE):
            if CANVAS[y][x] != key:
                errs.append("tile (0,0) must be all transparency key")
                break
    seen = {}
    for row, col, name, kind, fn in CATALOGUE:
        if (row, col) in seen:
            errs.append("two entries at r%d c%d" % (row, col))
        seen[(row, col)] = name
    # every terrain tile must be fully opaque, or the ground shows through it
    for row, col, name, kind, fn in CATALOGUE:
        if kind not in ("terrain", "terrain-single"):
            continue
        for cc in ((col, col + 1) if kind == "terrain" else (col,)):
            for y in range(TILE):
                for x in range(TILE):
                    if CANVAS[row * TILE + y][cc * TILE + x] == key:
                        errs.append("terrain tile r%d c%d has a transparent "
                                    "pixel (%d,%d)" % (row, cc, x, y))
                        break
    # every thing/unit tile must have SOME transparent ground, or it paints
    # the terrain out entirely
    for row, col, name, kind, fn in CATALOGUE:
        if kind not in ("thing", "unit"):
            continue
        if not any(CANVAS[row * TILE + y][col * TILE + x] == key
                   for y in range(TILE) for x in range(TILE)):
            errs.append("overlay tile r%d c%d (%s) is fully opaque"
                        % (row, col, name))
    for e in sorted(set(errs)):
        print("FAIL: %s" % e, file=sys.stderr)
    return not errs


# The specials that are TERRAIN though they are not features (src/ott-tiles.h):
# ott_hill_glyph() (cave.c) adds 1 to the column for a rise he knows but cannot
# see, as the lighting does for a feature, so each must name the lit tile of a
# pair.  Keyed by the index's number, however the S: line spells it.
TERRAIN_SPECIALS = {0x32: "OTT_TILE_SLOPE", 0x33: "OTT_TILE_CREST"}


def verify_prf(path):
    """Cross-check lib/pref/graf-ott.prf against the sheet this script draws.

    bin/data-tiles.py already checks the file's SHAPE.  This checks its
    MEANING: that every mapping lands on a tile that exists, that no terrain
    feature is pointed at a dim twin (the odd column of a pair -- the lighting
    code reaches those by adding one, so mapping a feature there would make
    "seen" and "remembered" the same picture, or worse the NEXT tile along),
    that a special drawn as terrain (TERRAIN_SPECIALS) names the lit tile of
    a pair for the same reason, and that nothing is pointed at a spare or
    unused slot, which is drawn as the magenta "no tile mapped here" hatch on
    purpose.
    """
    named = {}
    terrain_lit = set()
    terrain_paired = set()
    for row, col, name, kind, fn in CATALOGUE:
        named[(row, col)] = (name, kind)
        if kind in ("terrain", "terrain-single"):
            terrain_lit.add((row, col))
        if kind == "terrain":
            terrain_paired.add((row, col))
            named[(row, col + 1)] = ("the DIM twin of " + name, "dim")

    spare = {"unused", "spare", "unused terrain slot", "unused thing slot",
             "unused unit slot"}
    errs = []
    seen = 0
    with open(path) as f:
        for n, line in enumerate(f, 1):
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split(":")
            if len(parts) < 3 or parts[0] not in ("S", "F", "R"):
                continue
            coord = parts[-1]
            if "/" not in coord:
                continue
            try:
                a, c = (int(v, 16) for v in coord.split("/"))
            except ValueError:
                errs.append("line %d: cannot read the tile coord %r" % (n, coord))
                continue
            special = None
            if parts[0] == "S":
                try:
                    special = int(parts[1], 0)
                except ValueError:
                    errs.append("line %d: cannot read the special index %r"
                                % (n, parts[1]))
                    continue
            seen += 1
            row, col = a - 0x80, c - 0x80
            if not (0 <= row < ROWS and 0 <= col < COLS):
                errs.append("line %d: %s is off the sheet (%d rows x %d cols)"
                            % (n, coord, ROWS, COLS))
                continue
            what = named.get((row, col))
            if what is None or what[0] in spare:
                errs.append("line %d: %s is a spare/unused tile -- it is drawn "
                            "as the magenta hatch" % (n, coord))
                continue
            if what[1] == "dim":
                errs.append("line %d: %s is %s -- map the LIT tile (the even "
                            "column); the lighting code finds the twin itself"
                            % (n, coord, what[0]))
                continue
            if what[0].startswith("RESERVED"):
                errs.append("line %d: %s is %s -- reserved tiles are drawn but "
                            "deliberately unmapped" % (n, coord, what[0]))
                continue
            if parts[0] == "F" and (row, col) not in terrain_lit:
                errs.append("line %d: F: maps a feature to %s (%s), which is "
                            "not a LIT terrain tile" % (n, coord, what[0]))
            if (special in TERRAIN_SPECIALS
                    and (row, col) not in terrain_paired):
                errs.append("line %d: %s is drawn as terrain (its dim twin "
                            "is the next column) but %s is %s, not the LIT "
                            "tile of a terrain pair"
                            % (n, TERRAIN_SPECIALS[special], coord, what[0]))

    for e in errs:
        print("FAIL: %s" % e, file=sys.stderr)
    print("%s: %d mappings checked, %d problems" % (path, seen, len(errs)))
    return not errs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-dir", default=os.path.dirname(
        os.path.abspath(__file__)))
    ap.add_argument("--table", action="store_true",
                    help="print the tile index table and exit")
    ap.add_argument("--check", action="store_true",
                    help="only run the geometry/convention checks")
    ap.add_argument("--verify-prf", metavar="PRF", nargs="?",
                    const=os.path.join(os.path.dirname(os.path.dirname(
                        os.path.dirname(os.path.abspath(__file__)))),
                        "pref", "graf-ott.prf"),
                    help="cross-check a pref file's mappings against the sheet")
    args = ap.parse_args()

    build()

    if args.table:
        print_table()
        return 0

    if args.verify_prf:
        return 0 if verify_prf(args.verify_prf) else 1

    ok = check()
    if args.check:
        print("checks %s (%dx%d, %d tiles catalogued)"
              % ("passed" if ok else "FAILED", WID, HGT, len(CATALOGUE)))
        return 0 if ok else 1
    if not ok:
        return 1

    bmp = os.path.join(args.out_dir, "16x16_ott.bmp")
    png = os.path.join(args.out_dir, "16x16_ott.png")
    write_bmp(bmp)
    write_png(png)
    print("wrote %s and %s (%dx%d)" % (bmp, png, WID, HGT))
    return 0


if __name__ == "__main__":
    sys.exit(main())
